const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 10000;
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

const rooms = new Map();
const words = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function makeCode() {
  let code;
  do {
    code = Array.from({length:5}, () => words[Math.floor(Math.random()*words.length)]).join("");
  } while (rooms.has(code));
  return code;
}
function cleanName(name) {
  return String(name || "Player").trim().replace(/[<>]/g, "").slice(0, 20) || "Player";
}
function living(room) { return room.players.filter(p => p.alive); }
function playerById(room, id) { return room.players.find(p => p.id === id); }
function publicRoom(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    phase: room.phase,
    round: room.round,
    message: room.message,
    winner: room.winner,
    players: room.players.map(p => ({
      id: p.id, name: p.name, alive: p.alive,
      role: (room.phase === "end" || !p.alive) ? p.role : undefined,
      ready: !!p.ready,
      hasVoted: room.phase === "day" ? !!room.votes[p.id] : undefined
    })),
    action: room.phase === "night" ? room.nightStage : null,
    nightProgress: room.phase === "night" ? room.nightProgress : null
  };
}
function broadcast(room) {
  io.to(room.code).emit("state", publicRoom(room));
}
function sendPrivateRoles(room) {
  room.players.forEach(p => io.to(p.id).emit("privateRole", {
    role: p.role, description: descriptions[p.role]
  }));
}
const descriptions = {
  MAFIA: "At night, choose a living player to target with the other Mafia.",
  DOCTOR: "At night, protect one living player from the Mafia attack.",
  DETECTIVE: "At night, investigate one living player to learn if they are Mafia.",
  VILLAGER: "Discuss during the day and vote to eliminate a suspected Mafia member."
};
function checkWin(room) {
  const mafia = living(room).filter(p => p.role === "MAFIA").length;
  const town = living(room).length - mafia;
  if (mafia === 0) room.winner = "The Town wins!";
  else if (mafia >= town) room.winner = "The Mafia wins!";
  else return false;
  room.phase = "end";
  room.message = room.winner;
  broadcast(room);
  return true;
}
function assignRoles(room) {
  const n = room.players.length;
  const mafiaCount = Math.max(1, Math.floor(n / 4));
  const roles = [
    ...Array(mafiaCount).fill("MAFIA"),
    "DOCTOR", "DETECTIVE",
    ...Array(n - mafiaCount - 2).fill("VILLAGER")
  ];
  for (let i=roles.length-1; i>0; i--) {
    const j = Math.floor(Math.random()*(i+1));
    [roles[i], roles[j]] = [roles[j], roles[i]];
  }
  room.players.forEach((p,i) => {
    p.role = roles[i]; p.alive = true; p.ready = false;
  });
}
function startNight(room) {
  room.phase = "night";
  room.nightStage = "MAFIA";
  room.nightProgress = "Mafia are choosing";
  room.night = { mafiaChoices: {}, doctorTarget: null, detectiveDone: false };
  room.message = `Night ${room.round}: special roles, take your turns.`;
  advanceNight(room);
}
function advanceNight(room) {
  const alivePlayers = living(room);
  const has = role => alivePlayers.some(p => p.role === role);
  if (room.nightStage === "MAFIA" && !has("MAFIA")) room.nightStage = "DOCTOR";
  if (room.nightStage === "DOCTOR" && !has("DOCTOR")) room.nightStage = "DETECTIVE";
  if (room.nightStage === "DETECTIVE" && !has("DETECTIVE")) return resolveNight(room);
  if (room.nightStage === "MAFIA") {
    room.nightProgress = "Mafia are choosing";
    const mafias = alivePlayers.filter(p => p.role === "MAFIA");
    if (mafias.every(p => room.night.mafiaChoices[p.id])) {
      const counts = {};
      Object.values(room.night.mafiaChoices).forEach(id => counts[id] = (counts[id]||0)+1);
      const max = Math.max(...Object.values(counts), 0);
      const leaders = Object.keys(counts).filter(id => counts[id] === max);
      room.night.mafiaTarget = leaders.length === 1 ? leaders[0] : null;
      room.nightStage = "DOCTOR";
      advanceNight(room);
      return;
    }
  } else if (room.nightStage === "DOCTOR") {
    room.nightProgress = "Doctor is choosing";
    if (!has("DOCTOR") || room.night.doctorTarget) {
      room.nightStage = "DETECTIVE";
      advanceNight(room);
      return;
    }
  } else if (room.nightStage === "DETECTIVE") {
    room.nightProgress = "Detective is investigating";
    if (!has("DETECTIVE") || room.night.detectiveDone) return resolveNight(room);
  }
  broadcast(room);
}
function resolveNight(room) {
  const target = room.night.mafiaTarget && playerById(room, room.night.mafiaTarget);
  if (target && target.alive && String(target.id) !== String(room.night.doctorTarget)) {
    target.alive = false;
    room.message = `${target.name} was eliminated during the night. Their role was ${target.role}.`;
  } else if (target && target.alive) {
    room.message = "The Doctor saved the Mafia's target. Nobody was eliminated.";
  } else {
    room.message = "The night passed without an elimination.";
  }
  if (checkWin(room)) return;
  room.phase = "day";
  room.votes = {};
  room.message = room.message + " Discuss, then vote.";
  broadcast(room);
}

io.on("connection", socket => {
  socket.on("createRoom", ({name}, cb) => {
    const code = makeCode();
    const room = {
      code, hostId: socket.id, phase: "lobby", round: 1,
      message: "Waiting for players to join.", winner: null,
      players: [{id:socket.id, name:cleanName(name), alive:true, ready:false}],
      votes: {}, night: {}, nightStage: null, nightProgress: null
    };
    rooms.set(code, room);
    socket.join(code);
    cb && cb({ok:true, code});
    broadcast(room);
  });

  socket.on("joinRoom", ({code, name}, cb) => {
    code = String(code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return cb && cb({ok:false, error:"Room not found. Check the code."});
    if (room.phase !== "lobby") return cb && cb({ok:false, error:"This game has already started."});
    if (room.players.length >= 12) return cb && cb({ok:false, error:"This room is full (12 players maximum)."});
    if (room.players.some(p => p.name.toLowerCase() === cleanName(name).toLowerCase()))
      return cb && cb({ok:false, error:"That name is already in this room. Try another."});
    room.players.push({id:socket.id, name:cleanName(name), alive:true, ready:false});
    socket.join(code);
    cb && cb({ok:true, code});
    broadcast(room);
  });

  socket.on("startGame", (_data, cb) => {
    const room = [...rooms.values()].find(r => r.players.some(p => p.id === socket.id));
    if (!room) return cb && cb({ok:false, error:"Join a room first."});
    if (room.hostId !== socket.id) return cb && cb({ok:false, error:"Only the host can start the game."});
    if (room.phase !== "lobby") return cb && cb({ok:false, error:"Game already started."});
    if (room.players.length < 5) return cb && cb({ok:false, error:"At least 5 players are needed."});
    assignRoles(room);
    room.phase = "roles";
    room.message = "Check your private role, then wait for the host to begin the night.";
    sendPrivateRoles(room);
    broadcast(room);
    cb && cb({ok:true});
  });

  socket.on("beginNight", (_data, cb) => {
    const room = [...rooms.values()].find(r => r.players.some(p => p.id === socket.id));
    if (!room || room.hostId !== socket.id || room.phase !== "roles")
      return cb && cb({ok:false, error:"Only the host can start the night after roles are dealt."});
    startNight(room);
    cb && cb({ok:true});
  });

  socket.on("nightAction", ({targetId}, cb) => {
    const room = [...rooms.values()].find(r => r.players.some(p => p.id === socket.id));
    if (!room || room.phase !== "night") return cb && cb({ok:false,error:"It is not night."});
    const actor = playerById(room, socket.id);
    const target = playerById(room, String(targetId));
    if (!actor || !actor.alive || !target || !target.alive)
      return cb && cb({ok:false,error:"Choose a living player."});
    if (actor.id === target.id && actor.role !== "DOCTOR")
      return cb && cb({ok:false,error:"You cannot choose yourself."});

    if (room.nightStage === "MAFIA" && actor.role === "MAFIA") {
      if (room.night.mafiaChoices[actor.id]) return cb && cb({ok:false,error:"Your Mafia choice is already locked in."});
      if (target.role === "MAFIA") return cb && cb({ok:false,error:"Mafia cannot target another Mafia member."});
      room.night.mafiaChoices[actor.id] = target.id;
      cb && cb({ok:true, message:"Your choice is locked in."});
    } else if (room.nightStage === "DOCTOR" && actor.role === "DOCTOR") {
      room.night.doctorTarget = target.id;
      cb && cb({ok:true, message:"Your protection is locked in."});
    } else if (room.nightStage === "DETECTIVE" && actor.role === "DETECTIVE") {
      room.night.detectiveDone = true;
      socket.emit("investigationResult", {
        name: target.name, isMafia: target.role === "MAFIA"
      });
      cb && cb({ok:true, message:"Investigation complete. Your result is private."});
    } else {
      return cb && cb({ok:false,error:"It is not your role's turn, or your action is already complete."});
    }
    advanceNight(room);
  });

  socket.on("vote", ({targetId}, cb) => {
    const room = [...rooms.values()].find(r => r.players.some(p => p.id === socket.id));
    if (!room || room.phase !== "day") return cb && cb({ok:false,error:"It is not voting time."});
    const voter = playerById(room, socket.id);
    const target = playerById(room, String(targetId));
    if (!voter || !voter.alive || !target || !target.alive || voter.id === target.id)
      return cb && cb({ok:false,error:"Choose another living player."});
    if (room.votes[voter.id]) return cb && cb({ok:false,error:"You already voted."});
    room.votes[voter.id] = target.id;
    cb && cb({ok:true,message:"Your vote is recorded privately."});
    const livingPlayers = living(room);
    if (livingPlayers.every(p => room.votes[p.id])) {
      const counts = {};
      Object.values(room.votes).forEach(id => counts[id] = (counts[id]||0)+1);
      const max = Math.max(...Object.values(counts),0);
      const leaders = Object.keys(counts).filter(id => counts[id] === max);
      if (leaders.length === 1) {
        const eliminated = playerById(room, leaders[0]);
        eliminated.alive = false;
        room.message = `${eliminated.name} was voted out. Their role was ${eliminated.role}.`;
      } else {
        room.message = "The vote ended in a tie. Nobody was eliminated.";
      }
      if (checkWin(room)) return;
      room.round++;
      startNight(room);
    } else {
      broadcast(room);
    }
  });

  socket.on("disconnect", () => {
    for (const room of rooms.values()) {
      const index = room.players.findIndex(p => p.id === socket.id);
      if (index === -1) continue;
      if (room.phase === "lobby") {
        room.players.splice(index, 1);
        if (!room.players.length) rooms.delete(room.code);
        else {
          if (room.hostId === socket.id) room.hostId = room.players[0].id;
          broadcast(room);
        }
      } else {
        const p = room.players[index];
        p.connected = false;
        // Keep their seat and role. Disconnection does not reveal private information.
        io.to(room.code).emit("notice", `${p.name} disconnected. The game is paused for them to reconnect is not supported in this starter version.`);
        broadcast(room);
      }
    }
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`Mafia server listening on ${PORT}`));
